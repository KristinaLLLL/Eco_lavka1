package test.itschool.samsung.ru.eco_lavka;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class MainWidgets extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_widgets);

    }

}
