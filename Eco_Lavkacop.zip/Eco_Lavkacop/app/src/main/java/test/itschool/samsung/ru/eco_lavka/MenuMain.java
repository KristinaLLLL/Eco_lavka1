package test.itschool.samsung.ru.eco_lavka;

import android.app.ListActivity;
import android.content.Context;
import android.os.Bundle;
import android.widget.ArrayAdapter;

public class MenuMain extends ListActivity {
    final String[] categories = new String[] { "Молочные продукты", "Мясо", "Овощи", "Ягоды"};

    private ArrayAdapter<String> mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
    }
}
